using Dalamud.Configuration;
using Dalamud.Plugin;
using System;
using System.IO;
using System.Numerics;

namespace WhoIsWatchingMe;

[Serializable]
public class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;

    // --- Restore these two lines to fix CS0117 and CS1061 ---
    public static string BasePath = Plugin.PluginInterface.GetPluginConfigDirectory();
    public static string OriginalSoundFile => Path.Combine(BasePath, "assets", "alert.wav");

    public bool IsConfigWindowMovable { get; set; } = true;
    public bool SomePropertyToBeSavedAndWithADefault { get; set; } = true;
    public bool SoundEnabled { get; set; } = false;
    public bool SoundEnabledWindowClosed { get; set; } = false;
    public bool SuppressSoundWhileInDuty { get; set; } = true;
    public bool HideWindowWhileInDuty { get; set; } = false;
    public float SoundVolume { get; set; } = 0.5f;
    public string SoundFilePath { get; set; } = OriginalSoundFile;
    public bool StartOnStartup { get; set; } = false;
    public bool TellOption { get; set; } = true;
    public bool DoteOption { get; set; } = true;
    public bool AdventurePlateOption { get; set; } = true;
    public bool ExamineOption { get; set; } = true;
    public bool NoNoNo { get; set; } = false;
    public bool SearchInfoOption { get; set; } = true;
    public Vector4 titleColor { get; set; } = new Vector4(0.6f, 0.8f, 1.0f, 1.0f);
    public Vector4 targetingColor { get; set; } = new Vector4(0.0431f, 0.9569f, 0.1804f, 1.0000f);
    public Vector4 unloadedColor { get; set; } = new Vector4(0.5f, 0.5f, 0.5f, 1f);
    public Vector4 loadedColor { get; set; } = new Vector4(1f, 1f, 1f, 1f);

    public readonly string DevVersion = "1.5.0.0";

    public void Save()
    {
        Plugin.PluginInterface.SavePluginConfig(this);
    }
}
